import imgaug.augmenters as iaa
import numpy as np
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
from random import random


class ImgAug:
    def __init__(self, use_rotation_aug):
        if use_rotation_aug:
            self.aug = iaa.Sequential([
                # Sometime Flip & Fog
                iaa.Sometimes(0.5, iaa.Fliplr()),
                iaa.Sometimes(0.1, iaa.Fog()),

                # ETC
                iaa.SomeOf((0, 7), [
                    # General
                    iaa.Add((-60, 60)),
                    iaa.Affine(translate_percent={"x": (-0.2, 0.2), "y": (-0.2, 0.2)}),
                    iaa.Affine(rotate=(-35, 35)),
                    iaa.Affine(shear=(-20, 20)),
                    iaa.GammaContrast((0.3, 1.3)),

                    # Noise, Blur, Sharpen
                    iaa.OneOf([
                        iaa.AdditivePoissonNoise((0, 0.1*255)),
                        iaa.GaussianBlur((0, 2.5)),
                        iaa.Sharpen((0, 0.4)),
                    ]),

                    # Scale
                    iaa.OneOf([
                        iaa.Affine(scale={"x": (0.7, 1.3), "y": (0.7, 1.3)}),
                        iaa.Affine(scale=(0.7, 1.3)),
                    ]),
                ], random_order=True)
            ], random_order=True)
        else:
            # No Rotation
            self.aug = iaa.SomeOf((0, 8), [
                        iaa.Fliplr(1),
                        iaa.Add((-10, 10)),
                        iaa.AdditivePoissonNoise((0, 0.1*255)),
                        iaa.GaussianBlur((0, 4)),
                        iaa.Affine(translate_percent={"x": (-0.2, 0.2), "y": (-0.2, 0.2)}),
                        iaa.Affine(rotate=(-1.5, 1.5)),
                        iaa.Affine(scale=(0.8, 1.2))
                    ], random_order=True)

    def apply_aug(self, img, mask):
        """
        img : HxWxC
        mask : HxW (각 픽셀은 정수값으로 레이블링)
        """
        segmap = SegmentationMapsOnImage(mask, shape=img.shape)
        aug_img, aug_mask = self.aug(image=img, segmentation_maps=segmap)

        return aug_img, aug_mask.get_arr()

    def apply_aug_3d(self, imgs: np.array, masks: np.array, use_3d=False):
        """
        img : CxHxW
        mask : CxHxW (각 픽셀은 정수값으로 레이블링)
        모든 이미지에 같은 augmentation 적용을 위해서 16x256x256 -> 256x256x16으로 변환하는 트릭적용
        """
        imgs = np.moveaxis(imgs, 0, -1)
        if use_3d: masks = np.moveaxis(masks, 0, -1)

        segmap = SegmentationMapsOnImage(masks, shape=masks.shape)
        
        if use_3d:
            aug_imgs, aug_masks = self.aug(image=imgs, segmentation_maps=segmap)
            aug_imgs, aug_masks = np.moveaxis(aug_imgs, -1, 0), np.moveaxis(aug_masks.get_arr(), -1, 0)
        else:
            aug_imgs, aug_masks = self.aug(image=imgs, segmentation_maps=segmap)
            aug_imgs, aug_masks = np.moveaxis(aug_imgs, -1, 0), aug_masks.get_arr()

        # Random Order Invert
        if random()<0.4:
            aug_imgs = aug_imgs[::-1, ...]
            if use_3d: aug_masks = aug_masks[::-1, ...]

        return aug_imgs, aug_masks