import pandas as pd
import torch
import torch.utils.data


class ImbalancedDatasetSampler(torch.utils.data.sampler.Sampler):
    """Samples elements randomly from a given list of indices for imbalanced dataset
    Arguments:
        indices: a list of indices
        num_samples: number of samples to draw
        custom_weights: 레이블 weights를 커스텀조정 ex) {1: 0.05, 5: 0.1} -> 1번 레이블 5% 샘플링, 5번 레이블 10% 샘플링
    """

    def __init__(
        self,
        dataset,
        labels: list = None,
        indices: list = None,
        num_samples: int = None,
        custom_weights: dict = None,
    ):
        # if indices is not provided, all elements in the dataset will be considered
        self.indices = list(range(len(dataset))) if indices is None else indices

        # if num_samples is not provided, draw `len(indices)` samples in each iteration
        self.num_samples = len(self.indices) if num_samples is None else num_samples

        # distribution of classes in the dataset
        df = pd.DataFrame()
        df["label"] = self._get_labels(dataset) if labels is None else labels
        df.index = self.indices
        df = df.sort_index()

        label_to_count = df["label"].value_counts()
        if custom_weights:
            not_custom_label_sum = sum([label_to_count[x] for x in label_to_count.keys() if int(x) not in custom_weights])
            for key in custom_weights:
                label_to_count[key] = round(not_custom_label_sum * (1/custom_weights[key]))

        weights = 1.0 / label_to_count[df["label"]]
        self.weights = torch.DoubleTensor(weights.to_list())

    def _get_labels(self, dataset):
        return dataset.labels

    def __iter__(self):
        return (self.indices[i] for i in torch.multinomial(self.weights, self.num_samples, replacement=True))

    def __len__(self):
        return self.num_samples

class ExcludeSequentialSampler(torch.utils.data.sampler.Sampler):
    def __init__(self, data_source, exclude_labels: list=None):
        self.data_source = data_source
        self.labels = data_source.labels
        self.ex_indices = [i for i in range(len(self.labels)) if self.labels[i] not in exclude_labels]

    def __iter__(self):
        return (i for i in self.ex_indices)

    def __len__(self) -> int:
        return len(self.ex_indices)