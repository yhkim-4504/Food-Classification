import numpy as np
from torch import load

def load_state_dict_manually(model, pretrained_dict_path):
    pretrained_dict = load(pretrained_dict_path)
    model_dict = model.state_dict()

    for k, v in model_dict.items():
        if k in pretrained_dict and v.size()==pretrained_dict[k].size():
            model_dict[k].copy_(pretrained_dict[k])
        else:
            print(f'Missing Key - {k}')

def load_TransUnet(vit_name, vit_patches_size, n_skip, pretrained_weights, img_shape, class_list, use_3d, hybrid_inchan=3, **kwargs):
    from TransUNet.networks.vit_seg_modeling import VisionTransformer as ViT_seg
    from TransUNet.networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg
    vit_name = vit_name
    img_size = img_shape[0]
    vit_patches_size = vit_patches_size
    config_vit = CONFIGS_ViT_seg[vit_name]
    config_vit.n_classes = max(class_list)+1
    config_vit.n_skip = n_skip

    if vit_name.find('R50') != -1:
        config_vit.patches.grid = (int(img_size / vit_patches_size), int(img_size / vit_patches_size))
    model = ViT_seg(config_vit, img_size=img_size, num_classes=config_vit.n_classes, use_3d=use_3d, hybrid_inchan=hybrid_inchan)
    if pretrained_weights:
        model.load_from(weights=np.load(pretrained_weights))
    #    load_state_dict_manually(model, pretrained_weights)

    return model

def load_TransUnet_convnext(pretrained_weights, img_shape, class_list, **kwargs):
    from TransUnet_convnext.vit_seg_modeling import VisionTransformer
    from TransUnet_convnext.vit_seg_configs import get_r50_b16_config

    img_size = img_shape[0]
    config_vit = get_r50_b16_config()
    config_vit.n_classes = max(class_list)+1
    config_vit.n_skip = 3
    config_vit.patches.size = (16, 16)
    config_vit.patches.grid = (int(img_size/16), int(img_size/16))
    model = VisionTransformer(config_vit, img_size=img_shape, num_classes=config_vit.n_classes)

    if pretrained_weights:
        model.load_state_dict(load(pretrained_weights))

    return model