import time
import torch
import numpy as np
import matplotlib
import mlflow
matplotlib.use('agg')  # 에러발생방지
from torch.utils.data.sampler import RandomSampler, SequentialSampler
from pprint import pformat
from dataset import Dset3D
from torch.nn.modules.loss import CrossEntropyLoss
from custom_layers import *

import load_models
LOADER = {
    'model': {
        'TransUnet': load_models.load_TransUnet,
        'TransUnet_convnext': load_models.load_TransUnet_convnext,
    },
    
    'optimizer': {
        'AdamW': torch.optim.AdamW,
        'SGD': torch.optim.SGD,
    },
    
    'scheduler': {
        'NoneScheduler': NoneScheduler,
        'CustomCosineAnnealingWarmupRestarts': CustomCosineAnnealingWarmupRestarts,
        'ExpTargetIterScheduler': ExpTargetIterScheduler,
    }
}


class SegmentationTrainer:
    # ------------------------------------Initialization------------------------------------------------
    def __init__(self, config, config_select_dict, test_mode=False):
        # Init variables
        self.config = config
        self.config_select_dict = config_select_dict
        self.test_mode = test_mode
        self.img_shape = tuple(config['dataset']['img_shape'])
        self.cut_iter = self.config['trainer']['cut_iter']
        self.data_parallel = True if len(self.config['trainer']['cuda_device'].split(','))>=2 else False

        # Load model
        self.model = torch.nn.DataParallel(self.load_model()).cuda() if self.data_parallel else self.load_model().cuda()
        self.total_params = sum(p.numel() for p in self.model.parameters())
        print(f'Total Parameters : {self.total_params:,}')
        if not test_mode: mlflow.log_param('Parameters', self.total_params)
        
        # Load Dataset
        self.trainset = Dset3D(config['dataset']['trainset_path'], is_train=True, 
                            use_aug=config['trainer']['use_aug'], use_rotation_aug=config['trainer']['use_rotation_aug'],
                            **config['dataset'])
        self.validset = Dset3D(config['dataset']['validset_path'], is_train=False,
                            use_aug=False, use_rotation_aug=config['trainer']['use_rotation_aug'],
                            **config['dataset'])

        # Load Sampler
        custom_weights = self.config['trainer']['train_custom_weights']
        exclude_labels = self.config['trainer']['valid_exclude_labels']
        self.train_sampler = ImbalancedDatasetSampler(self.trainset, custom_weights=custom_weights) if custom_weights else RandomSampler(self.trainset)
        self.valid_sampler = ExcludeSequentialSampler(self.validset, exclude_labels=exclude_labels) if exclude_labels else SequentialSampler(self.validset)

        # Load dataloader
        num_workers = self.config['trainer']['num_workers']
        self.train_loader = torch.utils.data.DataLoader(self.trainset, batch_size=self.config['trainer']['train_batch_size'],
                                num_workers=num_workers, drop_last=True, sampler=self.train_sampler)
        self.valid_loader = torch.utils.data.DataLoader(self.validset, batch_size=self.config['trainer']['valid_batch_size'],
                                num_workers=num_workers, drop_last=False, sampler=self.valid_sampler)

        # Load loss, optimizer, scheduler
        self.ce_loss, self.dice_loss = self.load_loss_layer()
        self.optimizer = self.load_optimizer()
        self.scheduler = self.load_scheduler()

        # init training variables
        self.epoch = self.config['trainer']['start_epoch']
        self.ce_value = self.config['trainer']['ce_loss']
        self.dice_value = self.config['trainer']['dice_loss']
        self.chk_metric_scores = []
        
    def __str__(self):
        str_total_params = f'Total Parameters : {self.total_params:,}'
        str_config_select_dict = pformat(self.config_select_dict)
        str_config = pformat(self.config)

        return '\n\n'.join([str_total_params, str_config_select_dict, str_config, ''])

    # ------------------------------------Load Layers------------------------------------------------        
    def load_model(self):
        model_load_func = LOADER['model'][self.config_select_dict['model']]
        model_kwargs = self.config['model'][self.config_select_dict['model']]
        model_kwargs['img_shape'] = self.img_shape
        model_kwargs['class_list'] = self.config['dataset']['class_list']

        if self.config_select_dict['model'] == 'TransUnet':
            model_kwargs['use_3d'] = self.config['dataset']['use_3d']
        if 'UTNetV2' in self.config_select_dict['model']:
            model_kwargs['in_chan'] = self.config['dataset']['channel']

        return model_load_func(**model_kwargs)

    def load_loss_layer(self):
        return CrossEntropyLoss(), DiceLoss(max(self.config['dataset']['class_list'])+1)

    def load_optimizer(self):
        optim_load_func = LOADER['optimizer'][self.config_select_dict['optimizer']]
        optim_kwargs = self.config['optimizer'][self.config_select_dict['optimizer']]

        return optim_load_func(lr=self.config['trainer']['lr'], params=self.model.parameters(), **optim_kwargs)

    def load_scheduler(self):
        scheduler_load_func = LOADER['scheduler'][self.config_select_dict['scheduler']]
        scheduler_kwargs = self.config['scheduler'][self.config_select_dict['scheduler']]

        if self.config_select_dict['scheduler'] == 'CustomCosineAnnealingWarmupRestarts':
            # Set max_lr & first_cycle_stemps
            scheduler_kwargs['max_lr'] = self.config['trainer']['lr']
            scheduler_kwargs['first_cycle_steps'] = self.cut_iter if self.cut_iter!=-1 else len(self.train_loader)
            # Calc gamma
            init_lr = self.config['trainer']['lr']; gamma_last_lr = scheduler_kwargs['gamma_last_lr']
            target_epoch = self.config['trainer']['target_epoch']
            scheduler_kwargs['gamma'] = (gamma_last_lr/init_lr)**(1/target_epoch)

        return scheduler_load_func(optimizer=self.optimizer, **scheduler_kwargs)

    # ------------------------------------Train Methods------------------------------------------------
    def training_step(self, cut_iter=-1, verbose=True):
        max_iter_num = cut_iter if cut_iter!=-1 else len(self.train_loader)
        loss_list = []
        self.model.train()

        for iter_num, (image_batch, label_batch, _) in enumerate(self.train_loader):
            # forward
            image_batch, label_batch = image_batch.cuda(), label_batch.cuda()
            outputs = self.model(image_batch)
            
            # calc loss
            loss_ce = self.ce_loss(outputs, label_batch)
            loss_dice = self.dice_loss(outputs, label_batch, softmax=True)
            loss = self.ce_value*loss_ce + self.dice_value*loss_dice
            loss_list.append(loss.item())

            # backward
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            self.scheduler.step()

            # Print info
            if verbose:
                print('\rEpoch: {}, Train_Iter: {}/{}, loss: {}, lr: {}'
                    .format(self.epoch, iter_num+1, max_iter_num, round(np.mean(loss_list).item(), 8),
                            round(self.optimizer.param_groups[0]['lr'], 8)
                    )
                    , end=' ')

            # Cut epoch
            if cut_iter!=-1 and (iter_num+1)>=cut_iter:
                break

        return np.mean(loss_list).item()

    def validation_step(self, verbose=True):
        loss_list = []
        self.model.eval()

        with torch.no_grad():
            for iter_num, (image_batch, label_batch, _) in enumerate(self.valid_loader):
                # forward
                image_batch, label_batch = image_batch.cuda(), label_batch.cuda()
                outputs = self.model(image_batch)

                # Calc loss
                loss_ce = self.ce_loss(outputs, label_batch)
                loss_dice = self.dice_loss(outputs, label_batch, softmax=True)
                loss = self.ce_value * loss_ce + self.dice_value * loss_dice
                loss_list.append(loss.item())

                if verbose:
                    print('\rEpoch: {}, Valid_Iter: {}/{}, loss: {}'
                        .format(self.epoch, iter_num+1, len(self.valid_loader), round(np.mean(loss_list).item(), 8))
                        , end=' ')
                
        return np.mean(loss_list).item()
    # ------------------------------------Utils------------------------------------------------

    # ------------------------------------Run Train------------------------------------------------
    def run_train(self):
        # config variables
        target_epoch = self.config['trainer']['target_epoch']
        min_chkpoint_epoch = self.config['trainer']['min_chkpoint_epoch']
        
        metric = self.config['trainer']['metric']
        threshold = self.config['trainer']['threshold']
        chkpoint_range = self.config['trainer']['chkpoint_range']
        only_center_score = self.config['dataset']['only_center_score']
        
        # Set Chkpoint metric variables
        chkpoint_metric = self.config['trainer']['chkpoint_metric']
        if 'loss' in chkpoint_metric:
            compare_type = 'min'
            self.chk_metric_scores.append(float('inf'))
        else:
            chkpoint_metric = f'{metric}_{chkpoint_metric}'
            compare_type = 'max'
            self.chk_metric_scores.append(float('-inf'))

        # Start Training
        run_time_per_epoch = []
        while self.epoch <= target_epoch:
            epoch_start_time = time.time()

            # --------------------------------------------Train-----------------------------------------------------
            # Train & Valid step
            metric_dict = {}
            metric_dict['train_loss'] = self.training_step(cut_iter=self.cut_iter, verbose=True)
            metric_dict['valid_loss'] = self.validation_step(verbose=True)

            # Calc Metric
            valid_score = self.validset.calc_dataset_metric(self.model, metric=metric, threshold=threshold,
                            only_center_score=only_center_score, sampler=self.valid_sampler)
            valid_score['mean'] = np.mean([value for key, value in valid_score.items() if key!='mean' and key!=0]).item()
            for key, value in valid_score.items():
                metric_dict[f'{metric}_{key}'] = value

            # Chkpoint Save
            if (compare_type == 'min' and metric_dict[chkpoint_metric] < min(self.chk_metric_scores)) or \
                (compare_type == 'max' and metric_dict[chkpoint_metric] > max(self.chk_metric_scores)):
                mlflow.log_metric('chkpoint', metric_dict[chkpoint_metric], step=self.epoch)
                if self.epoch >= min_chkpoint_epoch:
                    under_epoch = (self.epoch//chkpoint_range + 1) * chkpoint_range  # Multiple Chkpoints
                    mlflow.pytorch.log_model(self.model.module if self.data_parallel else self.model, f'chkpoint_under_{under_epoch}epoch')
            
            # Log chkpoint scores
            if self.epoch >= min_chkpoint_epoch:
                self.chk_metric_scores.append(metric_dict[chkpoint_metric])

            # MLFlow logging
            mlflow.log_metrics(metric_dict, step=self.epoch)
            # -------------------------------------------------------------------------------------------------------

            # calc remaining time
            run_time_per_epoch.append(time.time()-epoch_start_time)
            per_epoch_time = np.mean(run_time_per_epoch[-50:]).item() ; remaining_time = (target_epoch-self.epoch) * per_epoch_time
            h, m = divmod(round(remaining_time), 3600); m, s = divmod(round(m), 60)

            # Print Info
            str_valid_scores = str({key: round(value, 3) for key, value in valid_score.items()})
            print('\rEpoch: {}/{}, train_loss: {}, valid_loss: {}, valid_metric: {}, remain_time: {}'
                .format(self.epoch, target_epoch, round(metric_dict['train_loss'], 6),
                        round(metric_dict['valid_loss'], 6), str_valid_scores,
                        f'{h:02}H_{m:02}M'
                        )
            )

            self.epoch += 1
