"""
2.5D모델 Inference 입니다.
CASE_PATH 변수에 폴더를 넣고 실행하면 됩니다.
함수 predict_case를 실행시키면 results라는 딕셔너리 데이터가 나옵니다.
케이스에 있는 이미지들의 인덱스마다 정보가 저장되어 있습니다.
'hemorrhage_info'는 'hemorrhage_type'과 'size'의 정보를 갖고있습니다.
'pred_mask'는 torch.Tensor 형식의 512x512 사이즈이며 예측한 레이블정보가 정수로 나타나있습니다.(현재는 ich이므로 0과 1뿐)
'sequential_images_path'는 예측에 이용된 연속된 3장 이미지의 경로를 담고있습니다.
"""

CASE_PATH = '/home/yhkim/workspace/project-CH-Labeling/labeld_dataset/labeld_dset4-5_220617/dataset/validset/CH/12907584 1539 20210503 0719/img'
CHKPOINT_PATH = './chkpoint_weights/base3_1k_ich_0.843'
IMG_SHAPE = (512, 512)  # 이미지 사이즈
CLASS_LIST = [0, 1]  # 0은 필수, 1:ich, 2:ivh
CHANNEL = 3  # 3장이 함께 Input으로 들어감
STEP = 1  # 1장씩 이동(슬라이딩 윈도우)

import os
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"]= '0'
import torch
import numpy as np
import matplotlib.pyplot as plt
import cv2
import mlflow
from os.path import join
from glob import glob
from tqdm import tqdm
from pprint import pprint

def predict_one_image(model, x, threshold=0.5):
    with torch.no_grad():
        pred = model(x.cuda().unsqueeze(0)).detach().squeeze()
        pred_softmax = torch.nn.functional.softmax(pred, dim=0).cpu()
        values, pred_mask = torch.max(pred_softmax, dim=0)
        pred_mask[values<threshold] = 0

    return pred_mask

def load_images_from_case(case_path):
    # channel 만큼의 이미지를 step 만큼 이동하며 경로저장
    image_list = sorted(glob(join(case_path, '*.??g')))
    seq_img_list = []
    for i in range(0, len(image_list)-CHANNEL+1, STEP):
        seq_img_list.append(image_list[i:i+CHANNEL])

    # 맨 앞복사
    seq_img_list.insert(0, seq_img_list[0].copy())
    seq_img_list[0].pop(-1)
    seq_img_list[0].insert(0, seq_img_list[0][0])

    # 맨 뒤복사
    seq_img_list.append(seq_img_list[-1].copy())
    seq_img_list[-1].pop(0)
    seq_img_list[-1].append(seq_img_list[-1][-1])

    return seq_img_list

def predict_case(model, case_path, class_list, threshold=0.5):
    results = dict()

    seq_img_list = load_images_from_case(case_path)
    for i, seq_img in enumerate(tqdm(seq_img_list, desc='Predicting Case')):
        # Read Sequential Images
        imgs = []
        for p in seq_img:
            image = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
            if image.shape[:2]!=IMG_SHAPE:
                image = cv2.resize(image, dsize=IMG_SHAPE, interpolation=cv2.INTER_CUBIC)
            imgs.append(image)
        
        # Input Tensor
        x = torch.FloatTensor(imgs)/255.0
        pred_mask = predict_one_image(model, x, threshold=threshold)

        # Calc hemorrhage pixel size & results
        results[i] = dict()
        results[i]['sequential_images_path'] = seq_img
        results[i]['pred_mask'] = pred_mask
        for cls_idx in class_list:
            if cls_idx==0: continue
            size = torch.sum(pred_mask==cls_idx).item()
            results[i].setdefault('hemorrhage_info', [])
            results[i]['hemorrhage_info'].append({'size': size, 'hemorrhage_type': cls_idx})
        
    return results

if __name__=='__main__':
    print('Model Loading...', end=' ')
    model = mlflow.pytorch.load_model(CHKPOINT_PATH).cuda()

    model.eval()
    print('Done.')

    results = predict_case(model, case_path=CASE_PATH, class_list=CLASS_LIST, threshold=0.5)
    pprint(results)