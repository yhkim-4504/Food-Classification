import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from glob import glob
from tqdm import tqdm
from torch.utils.data import Dataset
from image_augmentation import ImgAug
from utils import calc_dice, calc_iou
from os.path import join


class Dset3D(Dataset):
    def __init__(self, dset_path, class_list, img_shape, channel, step_size, pixel_limit_ratio,
            img_type, mask_type, is_train, use_3d, use_aug, use_rotation_aug, **kwargs):
        self.dset_path = dset_path
        self.case_list = sorted(glob(join(dset_path, '**/*')))
        self.img_shape = tuple(img_shape)
        self.channel = channel
        self.class_list = class_list

        self.pixel_limit_ratio = pixel_limit_ratio
        self.pixel_limit = int(self.img_shape[0]*pixel_limit_ratio)
        self.is_train = is_train
        self.use_3d = use_3d
        self.use_aug = use_aug
        self.use_rotation_aug = use_rotation_aug
        self.step_size = step_size
        self.img_aug = ImgAug(use_rotation_aug=use_rotation_aug)

        # Dataset folder
        self.img_type = img_type
        self.mask_type = mask_type
        self.mask_folder = f'img_mask_{self.mask_type}' if self.mask_type else 'img_mask'
        self.img_folder = f'img_{self.img_type}' if self.img_type else 'img'
        
        # Mask_path & labels
        self.sequential_masks = []
        self.labels = []

        # Read all case folders
        for folder in tqdm(self.case_list):
            # Read all mask_image
            mask_list = sorted(glob(join(folder, f'{self.mask_folder}/*.png')))

            # Copy first & last elements
            for _ in range(channel//2):
                mask_list.insert(0, mask_list[0])
                mask_list.append(mask_list[-1])

            for i in range(0, len(mask_list)-channel+1, self.step_size):
                seq_mask = mask_list[i:i+channel]
                self.sequential_masks.append(seq_mask)
                
                # Get labels
                exist_labels = set()
                mask = cv2.imread(seq_mask[len(seq_mask)//2], cv2.IMREAD_GRAYSCALE)
                for cls_idx in self.class_list:
                    if cls_idx==0: continue
                    pixel_num = np.sum(mask==cls_idx).item()
                    if pixel_num>int(mask.shape[0]*self.pixel_limit_ratio):
                        exist_labels.add(cls_idx)

                # Process labels set                            
                if exist_labels:
                    label = ''.join(map(str, sorted(exist_labels)))
                    self.labels.append(int(label))
                else:
                    self.labels.append(0)
                
    def __len__(self):
        return len(self.sequential_masks)
    
    def __getitem__(self, idx):
        mask_list = self.sequential_masks[idx]
        label = self.labels[idx]
        image_list = [x.replace(f'/{self.mask_folder}/', f'/{self.img_folder}/') for x in mask_list]
        
        if self.use_3d:
            # mask
            masks = []
            for p in mask_list:
                mask = cv2.imread(p, cv2.IMREAD_GRAYSCALE)    
                if tuple(mask.shape[:2])!=tuple(self.img_shape):
                    mask = cv2.resize(mask, dsize=self.img_shape, interpolation=cv2.INTER_NEAREST)

                label_mask = np.zeros(mask.shape, dtype=np.uint8)
                for cls_idx in self.class_list:
                    if cls_idx==0: continue
                    label_mask[mask==cls_idx] = cls_idx
                masks.append(label_mask)
        else:
            mask = cv2.imread(mask_list[len(mask_list)//2], cv2.IMREAD_GRAYSCALE)    
            if tuple(mask.shape[:2])!=tuple(self.img_shape):
                mask = cv2.resize(mask, dsize=self.img_shape, interpolation=cv2.INTER_NEAREST)

            label_mask = np.zeros(mask.shape, dtype=np.uint8)
            for cls_idx in self.class_list:
                if cls_idx==0: continue
                label_mask[mask==cls_idx] = cls_idx
                
        # Img
        imgs = []
        for p in image_list:            
            img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
            if tuple(img.shape[:2])!=tuple(self.img_shape):
                img = cv2.resize(img, dsize=self.img_shape, interpolation=cv2.INTER_CUBIC)
            imgs.append(img)

        np_imgs = np.array(imgs, dtype=np.uint8)
        if self.use_3d: label_mask = np.array(masks, dtype=np.uint8)
        else: label_mask = np.array(label_mask, dtype=np.uint8)
        
        # Augmentation
        if self.is_train and self.use_aug:
            np_imgs, label_mask = self.img_aug.apply_aug_3d(np_imgs, label_mask, use_3d=self.use_3d)

        return torch.FloatTensor(np_imgs.copy()/255.0), torch.LongTensor(label_mask.copy()), label

    def show_sample(self, idx):
        img, label_mask, label = self[idx]
        img = img.permute(1, 2, 0).squeeze()
        fig, ax = plt.subplots(figsize=(10, 5), ncols=2)
        ax[0].imshow(img, cmap='gray')
        ax[0].set_axis_off()
        ax[1].imshow(label_mask, cmap='gray', vmin=0, vmax=max(self.class_list))
        ax[1].set_axis_off()
        plt.suptitle(f'sample plot : {idx}, label : {label}')
        plt.show()
    
    def calc_dataset_metric(self, model, metric: str='dice', smooth=1e-5, threshold=0.5, only_center_score=False, center_idx=1, sampler=None):
        retrain_flag = False
        if self.is_train:
            self.is_train=False
            retrain_flag = True
            
        if metric=='dice': metric_function = calc_dice
        elif metric=='iou': metric_function = calc_iou
        else: raise Exception(f'{metric} is not included in the metric functions.')
        
        model.eval()
        class_score_dict = dict()
        class_score_dict['mean'] = []
        for cls_idx in self.class_list:
            class_score_dict.setdefault(cls_idx, [])
        
        index_iter = sampler if sampler else range(len(self.sequential_masks))
        for idx in tqdm(index_iter, desc=f'Calc {metric}'):
            with torch.no_grad():
                imgs, truth_masks, _ = self[idx]
                pred = model(imgs.unsqueeze(0).cuda()).detach().squeeze()
                pred_softmax = torch.nn.functional.softmax(pred, dim=0).cpu()
                values, pred_mask = torch.max(pred_softmax, dim=0)
                pred_mask[values<threshold] = 0
                if only_center_score:
                    truth_masks, pred_mask = truth_masks[center_idx], pred_mask[center_idx]
                score_list, score_mean = metric_function(truth_masks, pred_mask, self.class_list, self.pixel_limit)
            for key in score_list:
                if score_list[key]!=-1: class_score_dict[key].append(score_list[key])
            if score_mean!=-1: class_score_dict['mean'].append(score_mean)
            
        if retrain_flag:
            self.is_train = True
        
        for key in class_score_dict:
            class_score_dict[key] = np.mean(class_score_dict[key]).item()
        
        return class_score_dict